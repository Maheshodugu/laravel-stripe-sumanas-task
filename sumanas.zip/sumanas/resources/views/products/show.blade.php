
@extends('layouts.app')

@section('content')
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">{{ $product->name }}</h5>
            <p class="card-text">Price: ${{ $product->price }}</p>
            <form method="post" action="{{ route('stripe.charge') }}">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">
                <!-- Stripe credit card form here -->
                <script
                    src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                    data-key="YOUR_STRIPE_PUBLISHABLE_KEY"
                    data-amount="{{ $product->price * 100 }}"
                    data-name="{{ $product->name }}"
                    data-description="Payment for {{ $product->name }}"
                    data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
                    data-locale="auto">
                </script>
            </form>
        </div>
    </div>
@endsection
