<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\Charge;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('products.index', compact('products'));
    }

    public function show($id)
    {
        $product = Product::findOrFail($id);
        return view('products.show', compact('product'));
    }

    public function stripeCharge(Request $request)
    {
        // Stripe::setApiKey(env('STRIPE_SECRET'));
        Stripe::setApiKey(config('services.stripe.secret'));
        $product = Product::findOrFail($request->product_id);

        try {
            $charge = Charge::create([
                'amount' => $product->price * 100, // amount in cents
                'currency' => 'usd',
                'source' => $request->stripeToken, // obtained with Stripe.js
                'description' => 'Charge for ' . $product->name,
            ]);

            // Handle successful charge

            return back()->with('success', 'Payment completed successfully.');
        } catch (\Exception $e) {
            // Handle Stripe API exceptions
            return back()->with('error', 'Payment failed: ' . $e->getMessage());
        }
    }


}
