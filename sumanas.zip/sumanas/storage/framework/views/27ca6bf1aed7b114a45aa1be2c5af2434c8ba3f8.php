


<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($product->name); ?></h5>
            <p class="card-text">Price: $<?php echo e($product->price); ?></p>
            <form method="post" action="<?php echo e(route('stripe.charge')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                <!-- Stripe credit card form here -->
                <script
                    src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                    data-key="YOUR_STRIPE_PUBLISHABLE_KEY"
                    data-amount="<?php echo e($product->price * 100); ?>"
                    data-name="<?php echo e($product->name); ?>"
                    data-description="Payment for <?php echo e($product->name); ?>"
                    data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
                    data-locale="auto">
                </script>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\sumanas\resources\views/products/show.blade.php ENDPATH**/ ?>